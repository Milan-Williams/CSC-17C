/* Milan Williams 
 Professor Lehr 
 CIS 17C
 PROJECT 1
 10 NOVEMBER 2024 1:20 PM
 */
// I understood far to late when i realzied the project said no vectors 
// I really did have a hard time doing this project I really couldn't get 
// it to work the way that i inteded but I did try my very best to do what I could 
// I did try very hard to reach 750 lines of code but unfortuantly I was not able to 
// I did learn a lot from this project however and i understand that I have a lot more work to do
// And do plan on focusing much more on my coding aspect of this class

#include <iostream>
// This is the input for the standard input and output streams 
#include <vector>
//Provides the vector container, a dynamic array that can change size,
#include <ctime>
// Used this for the time related functions in the program 
#include <cstdlib>
// For the general use functions 
#include <string>
// of course needed this for the string class 
#include <algorithm>
// Used for the sort functions in the program 
#include <map>
// used to provide a map conatiner 
#include <set>
// Used to provide the set container 
#include <list>
// Used to provide the list container 
#include <stack>
// This is used to provide the stack container 
#include <queue>
// And last but not least the queue container 

// Enum to define different types of properties on the game board

enum PropertyType {
    PROPERTY,
    // This is normal property that can be bought 
    RAILROAD,
    // This is a special type of Property labeled RAILROAD
    UTILITY,
    // This is also a special property type Labeled UTILITY 
    TAX,
    // This too is a property type that benefits the player 
    JAIL,
    // This is a property type that forces a player to lose a turn
    COMMUNITY_CHEST,
    // Space on the board that draws a card for the player 
    CHANCE
    // Another space on the board that allows player to draw a card         
};

// This is the class that essentially represents the property on the game board 
class Property {
public:
    std::string name;
    // The name of the property here 
    int price;
    // The buying price for the property here 
    int rent;
    // The amount of rent that must be paid for landing on the property 
    bool owned;
    // This is for whether or not the property is owned 
    PropertyType type;
    // This is the type of property that it is (Property, Railroad, Utility etc)
    int ownerIndex;
    // This indexes the player that owns the property 
    
    // Constructor to initialize a property with a name, price, rent, and type
 
    // this constructor is what is going to start the code correctly
    Property(std::string name, int price, int rent, PropertyType type)
        : name(name), price(price), rent(rent), owned(false), type(type), ownerIndex(-1) {}

        // Method to print information about the property

    void printInfo() {
        std::cout << "Property: " << name << ", Price: " << price << ", Rent: " << rent;
        if (owned) {
            std::cout << " (Owned by Player " << ownerIndex + 1 << ")";
        }
        std::cout << std::endl;
        // Used endl and std:: in hopes that it improved code readability 
    }
};
// Class representing a player in the game

class Player {
public:
    std::string name;
    // This is what will represent the players name in the game 
    int money;
    // This will represent the amount of money the player has 
    int position;
    // this is where the player will be on the board 0-39
    std::set<int> ownedProperties;  
    // Set to avoid duplicate property ownership
    bool isInJail;
    // This is for whether or not th eplayer is in jail
    bool isBankrupt;
    // This is for if the player is bankrupt or not 

        // Constructor to initialize the player with a name and initial money

    Player(std::string name)
        : name(name), money(1500), position(0), isInJail(false), isBankrupt(false) {}

        // Method to move the player a certain number of steps on the board

    void move(int steps) {
               // Ensures player wraps around the board by
               // by taking the remainder of position/board size

        position = (position + steps) % 40;
        
    }
    // Method for a player to buy a property

    void buyProperty(int propertyIndex, std::vector<Property>& board) {
        if (!board[propertyIndex].owned && money >= board[propertyIndex].price) {
            // Will deduct the money from the player 
            money -= board[propertyIndex].price;
            // Add owned properties to the player 
            ownedProperties.insert(propertyIndex);
            // This will set the players owned propertys in the index
            board[propertyIndex].owned = true;
            // This will mark the property as owned 
            board[propertyIndex].ownerIndex = ownedProperties.size() - 1;
            // And this right here will set the owner index 
            std::cout << name << " bought " << board[propertyIndex].name << std::endl;
        }
    }
// this is the method in which a player will pay rent upon landing 
    // on a owned  property 
    void payRent(int rentAmount) {
        if (money >= rentAmount) {
            // Will deduct money from the player if they have the money 
            money -= rentAmount;
            std::cout << name << " paid rent of " << rentAmount << std::endl;
        } else {
            std::cout << name << " cannot afford rent of " << rentAmount << std::endl;
            declareBankruptcy();
            // This is the way a player is declared bankrupt if they can 
            // not afford to pay for the rent 
        }
    }
    // Method to declare bankruptcy when the player can't afford to pay rent or other fees

    void declareBankruptcy() {
        std::cout << name << " has gone bankrupt!" << std::endl;
        money = 0;
        // The amount of money that the player will have 
        // will be set to zero (0) in an event that they 
        // are not able to pay the rent 
        isBankrupt = true;
        // Set the bankrupcy as true 
        ownedProperties.clear();
        // This will remove all of the players owned properties from them
        // This will be done in all the player sets 
    }
    // Method to print the player's current status, including their money, position, and owned properties

    void printStatus() {
        std::cout << name << " - Money: " << money << ", Position: " << position << ", In Jail: " << isInJail << std::endl;
        std::cout << "Owned Properties: ";
        for (int idx : ownedProperties) {
            std::cout << idx << " ";
            // This will display all of the owned properties in the index 
        }
        std::cout << std::endl;
    }
    // Method to check if the player can afford a property purchase

    bool canAfford(int price) {
        return money >= price;
        // Ultimatly it will return as true if the player does have enough 
        // money to be able to purchase the property
    }
};

// Stack to simulate "Jail" stack
// This is the Queue for the players that will be in jail 
// skipping their turn 
class JailStack {
private:
    std::stack<int> jailQueue;
    // this stack is what will keep track of the players 
    // that are in jail 
public:
    // This is the way that players will get sent to jail 
    void enterJail(int playerIndex) {
        jailQueue.push(playerIndex);
        std::cout << "Player " << playerIndex + 1 << " has been sent to Jail." << std::endl;
    }
// this is the way in which players will be released from jail
    void releaseJail(int playerIndex) {
        if (!jailQueue.empty() && jailQueue.top() == playerIndex) {
            jailQueue.pop();
            std::cout << "Player " << playerIndex + 1 << " has been released from Jail." << std::endl;
        }
    }

    bool isInJail(int playerIndex) {
        std::stack<int> tempStack = jailQueue;
        // This will copy the jail queue 
        // It will be copied to a temp stck 
        while (!tempStack.empty()) {
            if (tempStack.top() == playerIndex) return true;
            // This will return as true if the player
            // is in fact in jail
            tempStack.pop();
            // This will remove the top item 
            // If it is not the correct player 
            // that the program is searching for 
        }
        return false;
        // Will return false if the player is not found in jail 
    }
};

// Queue for rolling dice
class DiceQueue {
private:
    std::queue<int> diceQueue;
    // This is the queue that will store the values 
    // For the dice in the game 
public:
    // This is the function that will
    // Simulate the rolling of the dice
    int rollDice() {
        int diceRoll = rand() % 6 + 1;
        // This will generate a number from 
        // 1- 6 
        diceQueue.push(diceRoll);
        // This will add the dice roll to the queue 
        return diceRoll;
    }

    int getLatestRoll() {
        // This is the function that will get 
        // the last dice roll from the queue 
        return diceQueue.back();
        // Return the most recent roll 
    }
};


// This is the class that represent the 
// community chest function in the game 
class CommunityChest {
private:
    std::list<std::string> cards;
    // List the Community Chest cards 
    // Also their functions 
    std::list<std::string>::iterator currentCard;
    // // Iterator to track current card

public:
    CommunityChest() {
        // These are the Community Chest cards that players 
        // Will be granted given they land on the space of the board 
        // that is labeled community chest these cards contain a variety 
        // of different outcomes the effect the gamplay some are positives 
        // and will benefit the player while other ones are not so postive 
        // and will hurt the player 
        // Initialize with some community chest cards
        cards.push_back("Advance to Go (Collect $200)");
        // This allows the player to advance to go and collect $200
        cards.push_back("Pay hospital fees of $100");
        // This requires the player to pay $100
        cards.push_back("You have won a crossword competition. Collect $100");
        // This allows the player to collect $200
        cards.push_back("Bank error in your favor. Collect $200");
        // This allows the player to collect $200 
        cards.push_back("Get out of Jail free card");
        // This is a card that the player can hold to get our of jail
        // not forcing them to skip a turn 
        cards.push_back("Pay school fees of $50");
        // This forces the player to pay $50
        cards.push_back("Go to jail. Go directly to jail. Do not pass Go, do not collect $200");
        // This forces the player to go to jail skip a turn and can not collect $200
        cards.push_back("You neglect your health and feel worse. Lose $5");
        // This forces players to lose $5
        cards.push_back("You lose your wallet. Lose $10");
        // This forces the player to lose $10
        cards.push_back("You procrastinate on a big task. Lose 2 turns.");
        // This forces the player to lose 2 turns
        cards.push_back("You cancel plans last minute. Lose $10.");
        // This forces the player to lose $10
        cards.push_back("You get stuck in a lie and hurt someone's feelings. Lose $20");
        // This forces the player to lose $20
        cards.push_back("You forget to check your bank balance and overdraft. Lose $15");
        // This forces the player to lose $15
        cards.push_back("You fail to make amends with someone you wronged. Lose $20"); 
        // This forces the player to lose $20
        cards.push_back("You oversleep and miss an important event. Lose $100");   
        // This forces the player to lose $100
        cards.push_back("You give bad advice to a friend. Lose $5.");      
        // This forces the player to lose $5
                currentCard = cards.begin();
                // Start iterator at beginning of the deck
    }

        // Function to draw a card from the Community Chest deck

    std::string drawCard() {
        std::string card = *currentCard;
        // This will get the card which will 
        // be in the form of text and it will 
        // be from the current iterator 
        currentCard++;
        // Then this right here will move 
        // the iterator to the next card 
        if (currentCard == cards.end()) {
            // this will reset the iterator 
            // if it is at the end of the list 
            currentCard = cards.begin();  // Reset after reaching the end
        }
        return card;
        // Then this will in fact 
        // return the drawn card description 
    }
};

// Now we have a map here that will 
// store the chance cards that have 
// integers keys and as well as 
// string descriptions 
class ChanceDeck {
private:
    std::map<int, std::string> chanceCards;

public:
    ChanceDeck() {
        // The constructor will initialize the chance cards
        // That all have specific typed messages and these
        // These are the cards that will be virtually given to players
        // When they land on the space called Chance the program 
        // Will give the player one of these cards and depending 
        // On which card is drawn will determine how it effects their game play 
        chanceCards[0] = "Advance to Go (Collect $200)";
        // Chance card advances player to go and they collect 200$
        chanceCards[1] = "Pay a fine of $150";
        // This card forces players to pay $150 dollars 
        chanceCards[2] = "Go to Jail. Go directly to Jail. Do not pass Go, do not collect $200";
        // This forces players to go to jail and not collect $200 for passing go 
        chanceCards[3] = "Move forward 3 spaces";
        // Allows players to move forward an additional 3 spaces 
        chanceCards[4] = "Bank pays you dividend of $50";
        // This card gives players an automatic $50 
        chanceCards[5] = "Collect $100 from every player";
        // This player will collect $100 dollars from all other players
        chanceCards[6] = "Lose $50 in a gambling game";
        // The player loses $50 
        chanceCards[7] = "You have a flat tire and lose a turn.";
        // Make player lose a turn 
        chanceCards[8] = "You find money on the ground! Collect $50.";
        // Player gets lucky and gains $50 
        chanceCards[9] = "You win a raffle! Collect $100";
        // Player gains $100 
        chanceCards[10] = "You meet a celebrity. Gain $25.";
        // Player gains $25 for meeting a celebrity 
        chanceCards[11] = "You win a free vacation! Gain $100";
        // Player gains $100 
        chanceCards[12] = "You catch an inspiring podcast. Gain $5";
        // Gain 5 more dollars 
        chanceCards[13] = "You forget someone's birthday. Lose $5";
        // Player loses $5 
        chanceCards[14] = "You make a great impression at an event. Gain $10.";
        //  The player will collect $10 
        chanceCards[15] = "Your phone dies. Lose 1 turn.";
        // This foreces the player to lose a turn 
        chanceCards[16] = "You bump into an old friend and catch up. Gain $5.";
        // This allows the player to collect $5
    
    
    
    }
    

    std::string drawCard() {
        // This will draw a random chance card 
        // rand() %7 this is what will generate 
        // the random index that is going to be 
        // between the number 0 and the number 6 
        // which will grant the card selection 
        int index = rand() % 7; // Now 7 cards in total
        // Then of course this will update if there 
        // would want to add some more cards 
        return chanceCards[index];
    }
};


class MonopolyGame {

private:
    // This is the collection of the players
    // That are actively participating 
    // in the game 
    std::vector<Player> players;
    std::vector<Property> board;
    // This is the virtural game board 
    // The game board has the properties 
    // it has the community chest 
    // It also has chance 
    // And last but not least it has the other spaces 
    JailStack jailStack;
    // This is the jail stack and ultimatly 
    // the purpose of this stack is to manage 
   //  the players that are sent to jail
    
    DiceQueue diceQueue;
    // this is the dice queue 
    CommunityChest communityChest;
    // Managing of the community chest 
    ChanceDeck chanceDeck;
    // Managing of the chance deck 
    int currentPlayerIndex;
    // This tracks which players 
    // turn that it is 
    bool gameOver;
    // This will indicate if the game
    // is over or when the game it over 
    int turnCount;
    // This will count the number of 
    // turns that have been taken so far 

    void initializeBoard() {
        // Initialize more properties and additions
        // Essentially these are the spaces for the virtual gaming board
        // We have all the properties that can be purchased 
        // As well as the spaces for chance cards community chest cards and jail
        board.push_back(Property("Go", 0, 0, PROPERTY));
        // This is the Go and the board or in other words the starting position
        board.push_back(Property("Mediterranean Avenue", 60, 2, PROPERTY));
        // This is the property Mediterranean Avenue 
        board.push_back(Property("Community Chest", 0, 0, COMMUNITY_CHEST));
        // This is the space for the community chest
        board.push_back(Property("Baltic Avenue", 60, 4, PROPERTY));
        // This is the property Baltic Avenue 
        board.push_back(Property("Income Tax", 0, 200, TAX));
        // This is the space where the player can gain additional cash by landing on it 
        board.push_back(Property("Reading Railroad", 200, 25, RAILROAD));
        // Thid is the property Reading Railroad 
        board.push_back(Property("Oriental Avenue", 100, 6, PROPERTY));
        // This is the pproperty Oriental Avenue 
        board.push_back(Property("Chance", 0, 0, CHANCE));
        // This is the other space for the chance landing space
        board.push_back(Property("Vermont Avenue", 100, 6, PROPERTY));
        // This is the property for Vermont Avenue 
        board.push_back(Property("Connecticut Avenue", 120, 8, PROPERTY));
        // This is the property Connecticut Avenue
        board.push_back(Property("Jail", 0, 0, JAIL));
        // This is the space when a player lands on can be visiting or 
        // if they draw the go to jail card they are required to be there 
        // and as a result will miss a turn
        board.push_back(Property("St. Charles Place", 140, 10, PROPERTY));
        // This is the property St. Charles place
        board.push_back(Property("Electric Company", 150, 0, UTILITY));
        // This is the space for Electric Company
        board.push_back(Property("States Avenue", 140, 10, PROPERTY));
        // This is the property States Avenue 
        board.push_back(Property("Virginia Avenue", 160, 12, PROPERTY));
        // This is the property Virgina Avenue 
        board.push_back(Property("Community Chest", 0, 0, COMMUNITY_CHEST));
        // This is another space for the community chest 
        board.push_back(Property("St. James Place", 180, 14, PROPERTY));
        // This is the property for St. James Place 
        board.push_back(Property("Tennessee Avenue", 180, 14, PROPERTY));
        // This is the property Tennessee Avenue 
        board.push_back(Property("New York Avenue", 200, 16, PROPERTY));
        // This the property New York Avenue 
        board.push_back(Property("Free Parking", 0, 0, PROPERTY));
        // This is the property for Free Parking 

        // Adding additional properties
        board.push_back(Property("Kentucky Avenue", 220, 18, PROPERTY));
        //Push back property for Kentucky Avenue
        board.push_back(Property("Chance", 0, 0, CHANCE));
        //Push back property for chance 
        board.push_back(Property("Indiana Avenue", 220, 18, PROPERTY));
        // Property for Indiana Avenue
        board.push_back(Property("Illinois Avenue", 240, 20, PROPERTY));
        // Property Illinois avenue 
        board.push_back(Property("B&O Railroad", 200, 25, RAILROAD));
        // Property for the railroad
        board.push_back(Property("Atlantic Avenue", 260, 22, PROPERTY));
        //Property Atlantic Avenue 
        board.push_back(Property("Ventnor Avenue", 260, 22, PROPERTY));
        //Property ventnor avenue 
        board.push_back(Property("Water Works", 150, 0, UTILITY));
        // Property Water works 
        board.push_back(Property("Marvin Gardens", 280, 24, PROPERTY));
        // Property Marvin Gardens 
        board.push_back(Property("Go to Jail", 0, 0, JAIL));
        // Space that makes the unlucky player that landed on it go to jail
        board.push_back(Property("Pacific Avenue", 300, 26, PROPERTY));
        // Property Pacific Avenue 
        board.push_back(Property("North Carolina Avenue", 300, 26, PROPERTY));
        // This is North Carolina Avenue 
        board.push_back(Property("Community Chest", 0, 0, COMMUNITY_CHEST));
        //This is the space for the Community Chest cards which a chance cards basically 
        board.push_back(Property("Pennsylvania Railroad", 200, 25, RAILROAD));
        // this is the property Pennsylvania Railroad 
        board.push_back(Property("Park Place", 350, 35, PROPERTY));
        //This is property park place 
        board.push_back(Property("Chance", 0, 0, CHANCE));
        // this is the space for the chance cards 
        board.push_back(Property("Boardwalk", 400, 50, PROPERTY));
        // this is the property for the board walk 
    }


public:
   
    MonopolyGame(int numPlayers) : currentPlayerIndex(0), gameOver(false), turnCount(0) {
        // This is going to be the constructor 
        // that will initializes the players 
        // it will also initialize the board 
        // and it will set up what the 
        // intial conditons of the game will be 
        for (int i = 0; i < numPlayers; ++i) {
            // The loop will create each of the players 
            // Then it will construct what the player objects are 
            // and that can be seen by things such as 
            // for example "Player 1" or "Player 2"
            // Then it will add the created player object to 
            // the vector of the player 
            players.push_back(Player("Player " + std::to_string(i + 1)));
            // This part of the function will 
            // essentially add the players to the 
            // game and will supply them with 
            // a unique identifier 
        }
        initializeBoard();
        // This is what prepares the board for 
        // play with the properties and as well
        // as the specialized spaces that are in 
        // the game
    }

    void playTurn() {
        // This function is to handle each of the players 
        // turn in the game 
        if (gameOver) {
            // If the gameover rings to be true 
            // the game has ended so nothing will happen 
            std::cout << "The game is over!" << std::endl;
            return;
        }

        Player& currentPlayer = players[currentPlayerIndex];
        // This will get the current player 
        // whose turn it is that is based on 
        // the current players index 
        if (currentPlayer.isBankrupt) {
            // This will check if the current player 
            // is bankrupt and if the current player 
            // does in fact turn out to be bankrupt 
            // it will ultimalty skip that players turn
            currentPlayerIndex = (currentPlayerIndex + 1) % players.size();
            return;
        }

        std::cout << "\nIt's " << currentPlayer.name << "'s turn!" << std::endl;
        // This is kinda cool because it will 
        // Announce whichever players turn it is 
        currentPlayer.printStatus();
        // This will then print out the 
        // current players status in the game 
        // this would be money properties that are owned 

        // Roll the dice
        int diceRoll = diceQueue.rollDice();
        // This will simulate the rolling of the dice 
        // the dice roll is what influences player movement 
        // inside of the game
        std::cout << "Dice Roll: " << diceRoll << std::endl;
        // Then finally this is what will display 
        // the results of the dice roll
        currentPlayer.move(diceRoll);
        // And last but not least this is what 
        // is responsible for moving the player 
        // based on the results from the dice roll

        // Handle the landed property
        Property& landedProperty = board[currentPlayer.position];
        // This will check whether or not 
        // the player has landed on a ownable property 
        // of course this isn't just properties it also 
        // checks for the RAILROAD as well as tax and utility 
        
        std::cout << currentPlayer.name << " landed on " << landedProperty.name << std::endl;
        // Here if the property turns out to be unowned 
        // The game will prompt the user to see if 
        // They would like to buy it 

        if (landedProperty.type == PROPERTY || landedProperty.type == RAILROAD || landedProperty.type == UTILITY) {
            // This will check if the player has 
            // enough money to purchase the property 
            
            if (!landedProperty.owned) {
                // If the property is unowned then the 
                // user can attempt to buy it 
                // Attempt to buy the property if it's not owned
                if (currentPlayer.canAfford(landedProperty.price)) {
                    // This will check if the player can afford
                    // to buy the property 
                    std::cout << currentPlayer.name << ", do you want to buy this property? (y/n): ";
                    char choice;
                    std::cin >> choice;
                    // This waits for the player to make
                    // a decision to see if they choose to purchase it
                    if (choice == 'y' || choice == 'Y') {
                        // If the user chooses to actually
                        // buy the property 
                        currentPlayer.buyProperty(currentPlayer.position, board);
                        // This will process the purchase and 
                        // will assign that particular 
                        // property to the user 
                    }
                }
            } else {
                // If the property is already owned 
                // by another player 
                // Pay rent to the owner
                Player& owner = players[landedProperty.ownerIndex];
                // This will then retrieve the owner 
                // of the property and essentially it will
                // access their index 
                if (owner.name != currentPlayer.name) {
                    // if the owner is not the current 
                    // player someone else is the one 
                    // who actually owns it 
                    std::cout << "Paying rent of " << landedProperty.rent << " to " << owner.name << std::endl;
                    // This right here is what is going to 
                    // Display the rent payment information 
                    currentPlayer.payRent(landedProperty.rent);
                    // This is what is going to deduct the rent from 
                    // the players money 
                    owner.money += landedProperty.rent;
                    // Then this is what will finally add
                    // the money to the other player that 
                    // owns that specific property
                }
            }
        }
       
        else if (landedProperty.type == COMMUNITY_CHEST) {
            // This will handle when one of the players 
            // Lands on the community chest space 
            std::string card = communityChest.drawCard();
            std::cout << "Community Chest: " << card << std::endl;
            // This draws a card and then it will display
            // The community event or the text from the 
            // specific card that was pulled
            // Handle community chest effects here (e.g., adjust money, send to jail)
       
        }
      
        else if (landedProperty.type == CHANCE) {
            // This is what will handle the times when 
            // a player lands on the chance space of the board 
            std::string card = chanceDeck.drawCard();
            
            std::cout << "Chance: " << card << std::endl;
            // Handle chance effects here
            // Draws a card and it will display the chance event 
            // The effects of the chance card will be 
            // handled in this function 
        } else if (landedProperty.type == JAIL) {
            // This what is going to take care of when 
            // one of the players land on the jail space of
            // the board 
           
            std::cout << currentPlayer.name << " is in Jail!" << std::endl;
            // This will announce that that player is now in jail
            // There are additional jail rules that also could 
            // apply here like having to miss a turn as well 
            // as having the player pay a fine 
            // Handle jail conditions
        }

        // Check for bankruptcy
        if (currentPlayer.money <= 0) {
            // If the player has 0 money or less 
            // then bankruptcy will then be declared 
            // for that player 
            currentPlayer.declareBankruptcy();
            // this will declare that the current player 
            // is now bankrupt and will have to adjust 
            // the state of the game accordinly 
        }

        // Move to the next player
        currentPlayerIndex = (currentPlayerIndex + 1) % players.size();
        // This will update the currentPlayerIndex 
        // to the next player and this is one by using modulo 
        // that essentially will loop back to the first player
        // however this will only happen if it is neccessary 
        turnCount++;
        // This is just the increment of the turn count 
    }

    
    void startGame() {
        // This is essentially the function that 
        // starts the game and runs the game loop
        while (!gameOver) {
            // This one continue to run the game 
            // when the game is not over 
            playTurn();
            // Determine if the game is over 
            // based on bankruptcies or other conditions
        }
    }
};

int main() {
    srand(time(0));  
    // Initialize random seed
    // based on the current time of the randomise 
    // In the card drawing and the dice rolling 

    int numPlayers;
    
    std::cout << "Enter number of players: ";
    // This is what will prompt the user to enter 
    // How many players there will be playing the game 
   
    std::cin >> numPlayers;
    // This is when the user will have the options to 
    // give their input and decide how many players 
    // will be playing the game with them 

   
    MonopolyGame game(numPlayers);
    // This is what creates the new Monopoly game 
    // This is an instance of course with the specified number of players 
    
    game.startGame();
// This is what calls the start of the game 
    // To begin the game loop 
    // it will begin the game loop accordingly 
    return 0;
}
